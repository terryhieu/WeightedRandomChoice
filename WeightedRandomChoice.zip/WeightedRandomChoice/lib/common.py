
import json
import os
import random

'''
To get full path of config file
Output:
    Full path of json config file config.json
'''
def get_cfg_file_path():
    path = os.getcwd() + '/config/config.json'
    
    return path

CFG_FILE = get_cfg_file_path()

'''
Load the whole config file file
'''
def _get_all_config():
    cfg_file = get_cfg_file_path()

    with open(cfg_file) as f: 
        data = json.load(f)
    
    return data

'''
'''
def _get_specific_config(key):
    cfg_dict = _get_all_config()
    
    return cfg_dict[key]

'''
Load run parameters only: min_n, max_n, min_weight, max_weight
Output: 
    Run cfg run_cfg dictionary in config/config.json
'''
def get_run_config():
    key = 'run_cfg'    
    
    return _get_specific_config(key)

'''
'''
def get_run_cfg_min_n():
    key = 'min_n'

    return get_run_config()[key]

'''
'''
def get_run_cfg_max_n():
    key = 'max_n'

    return get_run_config()[key]

'''
'''
def get_run_cfg_min_weight():
    key = 'min_weight'

    return get_run_config()[key]

'''
'''
def get_run_cfg_max_weight():
    key = 'max_weight'

    return get_run_config()[key]

'''
Get test config parameters: log_level, accept_wrong_ratio, accept_percent_diff_each_msg_ver
Output: 
    Test cfg test_cfg dictionary in config/config.json
'''
def get_test_config():
    key = 'test_cfg'    
    
    return _get_specific_config(key)

'''
'''
def get_test_cfg_accept_wrong_percent_in_total():
    key = 'accept_wrong_percent_in_total'

    return get_test_config()[key]

# '''
# '''
# def get_test_cfg_accept_percent_diff_each_msg_ver():
#     key = 'accept_percent_diff_each_msg_ver'

#     return get_test_config()[key]

'''
'''
def get_test_cfg_runtime_default():
    key = 'runtime'

    return get_test_config()[key]

'''
'''
def get_test_cfg_runtime_small():
    key = 'runtime_small'

    return get_test_config()[key]

'''
'''
def get_test_cfg_runtime_medium():
    key = 'runtime_medium'

    return get_test_config()[key]

'''
'''
def get_test_cfg_runtime_large():
    key = 'runtime_large'

    return get_test_config()[key]

'''
Get list error message from config/config.json file
Output:
    Dict of error message
'''
def get_list_err_msg_prefix():
    key = 'err_msg_prefix'

    return _get_specific_config(key)

'''
'''
def get_err_msg_prefix_invalid_n():
    key = 'invalid_n'

    return get_list_err_msg_prefix()[key]

'''
'''
def get_err_msg_prefix_invalid_weight():
    key = 'invalid_weight'

    return get_list_err_msg_prefix()[key]

'''
generate a random int array n element in range(min, max)
Output:
    Array of int in range (min, max)
'''
def generate_random_int_array(n, min, max):   
    arr = []
        
    if n < 0 or max < min:
        raise Exception('Invalid (n, min, max): (%d, %d, %d)' % (n, min, max))

    for i in range(n):
        arr.append(random.randint(min, max))

    return arr

if __name__ == '__main__':    
    pass