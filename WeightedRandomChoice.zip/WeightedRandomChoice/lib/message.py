import random
import bisect
import common

'''
Validate if n, weight parameter is valid
Output:
    (True/False, Error message)
'''
def _validate_n_weight(weights):
    is_n_valid, err_msg_n, n = True, '', 0
    is_w_valid, err_msg_w = True, ''
    err_msg = ''
    min_n, max_n = 0, 0
    min_w, max_w = 0, 0
    err_msg_prefix_invalid_n, err_msg_prefix_invalid_weight = '', ''

    min_n = common.get_run_cfg_min_n()
    max_n = common.get_run_cfg_max_n()
    n = len(weights)

    min_w = common.get_run_cfg_min_weight()
    max_w = common.get_run_cfg_max_weight()

    err_msg_prefix_invalid_n = common.get_err_msg_prefix_invalid_n()
    err_msg_prefix_invalid_weight = common.get_err_msg_prefix_invalid_weight()

    if n < min_n or n > max_n:
        is_n_valid = False
        err_msg_n = '%s parameter. n: %d out of range (min_n, max_d): (%d, %d)' % \
                    (err_msg_prefix_invalid_n, n, min_n, max_n)    
    
    for i, w in enumerate(weights):
        if w < min_w or w > max_w:            
            if err_msg_w == '':
                err_msg_w = '(%d, %d)' % (i, w)
            else:
                err_msg_w = err_msg_w + ', ' + '(%d, %d)' % (i, w)

    if err_msg_w != '':
        is_w_valid = False
        err_msg_w = '%s. Valid weight range (min_w, max_w): (%d, %d). List invalid weights (index, w): ' % \
                        (err_msg_prefix_invalid_weight, min_w, max_w) + err_msg_w
    
    err_msg = err_msg_n

    if err_msg_w != '':
        if err_msg == '':
            err_msg = err_msg_w
        else:
            err_msg = err_msg + '.\n' + err_msg_w  

    return (is_n_valid and is_w_valid, err_msg)

'''
Generate a random message base on its weights.
Output:
    - msg version id or -1 if not found
'''
def generate_random_message_ver(weights):  
    is_valid, err_msg = True, False

    is_valid, err_msg = _validate_n_weight(weights)
    if not is_valid:
        raise Exception(err_msg)
        
    msg_ver = -1

    rnd_no = int(random.random() * sum(weights))
    for i, w in enumerate(weights):
        rnd_no -= w
        if rnd_no < 0:
            msg_ver = i
            break
    
    return msg_ver

'''
Generate expected msg version distribution base on weights and runtime
Output:
    Expected msg version distribution according to its weights.
'''
def generate_expected_msg_distribution(weights, runtime):    
    expected_msg_dist = []
    total_weight = sum(weights)

    for i, w in enumerate(weights):
        # calc weight percent of this element
        # in some case, total_weight may be zero
        try:            
            w_percent = float(w*100)/float(total_weight)        
        except ZeroDivisionError as e:
            w_percent = 0
        # calc expected distribution for this message version
        expected_msg_dist.append(int((w_percent*runtime)/100))

    return expected_msg_dist

'''
Get a list message distribution according to len of weights. 
No of message = runtime
Output
    An array of message version
'''
def get_actual_msg_distribution(weights, runtime):
    actual_msg_dist = []

    if runtime < 1:
        raise Exception('Invalid runtime: %d' % runtime)

    # initialize actual_msg_dist with zero value and len = len(weights)
    actual_msg_dist = common.generate_random_int_array(len(weights), 0, 0)
   
    #get actual message version based on its weights
    for r in range(runtime):
        msg_ver_i = generate_random_message_ver(weights)
        if msg_ver_i >= 0:
            actual_msg_dist[msg_ver_i] += 1

    return actual_msg_dist

'''
Get list index of actual message different from expected message dist.
Output:
    Array of message index if different or Empty.
'''
def get_list_msg_idx_wrong_distribution(expected_msg_dist, actual_msg_dist):    
    list_msg_diff = []
    n = len(expected_msg_dist)
    
    # calc % distribution diff of each message version
    for i in range(n):
        #Check if this msg version got wrong distribution 
        if expected_msg_dist[i] != actual_msg_dist[i]:
            list_msg_diff.append(i)    

    return list_msg_diff      

'''
Count number of message version is distributed incorrectly. So, either count:
    1. Items from actual_msg_list is GREATER THAN expected_msg_list
    	OR 
    2. Items from actual_msg_list is LESS THAN expected_msg_list
This function uses method #1
Output:
    Number of messages are distributed incorrecly
'''
def count_msg_wrong_distribution(expected_msg_dist, actual_msg_dist):    
    wrong_dist_count = 0
    n = len(expected_msg_dist)
    
    # calc % distribution diff of each message version
    for i in range(n):
        if actual_msg_dist[i]  > expected_msg_dist[i]:
            wrong_dist_count += actual_msg_dist[i] - expected_msg_dist[i]
                    
    return wrong_dist_count

if __name__ == '__main__':
    w = [0]
    print generate_random_message_ver(w)

    