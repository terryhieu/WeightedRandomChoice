import unittest
import TestRandomMessage
import os

suite = unittest.TestSuite()
loader = unittest.TestLoader()
suite.addTest(loader.loadTestsFromModule(TestRandomMessage))

runner = unittest.TextTestRunner(verbosity=3)
result = runner.run(suite)

print result
