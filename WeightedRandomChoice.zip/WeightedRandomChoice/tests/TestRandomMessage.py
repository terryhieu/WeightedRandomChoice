
import unittest
import logging
import os
import sys
import random

sys.path.append(os.getcwd())
import lib.message as lib_msg
import lib.common as lib_co

logger = logging.getLogger()
logger.level = logging.INFO

logging.basicConfig(
    format="\n%(asctime)-15s [%(levelname)s]: %(message)s",
    level=logging.INFO
)

# logger.addHandler(logging.StreamHandler(sys.stdout))

'''
Define Test Class to do unit test for 
'''

class TestGenerateRandomMessageVer(unittest.TestCase):
    # run config
    min_n = 0
    max_n = 0
    min_weight = 0
    max_weight = 0
    run_cfg = {}

    # test config
    accept_wrong_percent_in_total = 0
    #accept_percent_diff_each_msg_ver = 0
    runtime = 0
    test_cfg = {}

    err_msg_prefix_invalid_n = ''
    err_msg_prefix_invalid_weight = ''

    '''
    Initialize needed parameters from config file config/config.json
    '''

    def __init__(self, *args, **kwargs):
        super(TestGenerateRandomMessageVer, self).__init__(*args, **kwargs)

        # Get needed parameter from config file
        self.min_n = lib_co.get_run_cfg_min_n()
        self.max_n = lib_co.get_run_cfg_max_n()
        self.min_weight = lib_co.get_run_cfg_min_weight()
        self.max_weight = lib_co.get_run_cfg_max_weight()
        self.run_cfg = lib_co.get_run_config()

        self.accept_wrong_percent_in_total = lib_co.get_test_cfg_accept_wrong_percent_in_total()
        self.test_cfg = lib_co.get_test_config()
        # Get runtime info
        self.runtime = lib_co.get_test_cfg_runtime_default()

        self.err_msg_prefix_invalid_n = lib_co.get_err_msg_prefix_invalid_n()
        self.err_msg_prefix_invalid_weight = lib_co.get_err_msg_prefix_invalid_weight()

    def setUp(self):
        pass

    '''
    As developer, I want to test the case n < min_n value. So that, check if the function handles invalid n correctly.

    Test info:
        - n: less than min_n
        - weights: random between min_weight and max_weight
        - runtime: Use default runtime from config/config.json
    Expect:
        The function generate_random_message_ver handles n < min_n correctly
    '''
    def test_invalid_n_less_than_min_n(self):
        # logger.info('Start')
        n = self.min_n - 1
        w = lib_co.generate_random_int_array(
            n, self.min_weight, self.max_weight)

        logger.debug('Test parameters (n, weights): (%d, %s)' % (n, w))
        with self.assertRaises(Exception) as context:
            lib_msg.generate_random_message_ver(w)

        self.assertIn(
            self.err_msg_prefix_invalid_n, context.exception.message,
            'Not found key: %s in error message: %s' % (
                self.err_msg_prefix_invalid_n, context.exception.message)
        )

        # logger.info('Finish')

    '''
    As developer, I want to test the case n > max_n value.  So that, check if the function handles invalid n correctly.

    Test info:
        - n: greater than max_n
        - weights: random between min_weight and max_weight
        - runtime: Use default runtime from config/config.json
    Expect:
        The function generate_random_message_ver handles n > max_n correctly
    '''
    def test_invalid_n_greater_than_max_n(self):
        n = self.max_n + 1
        w = lib_co.generate_random_int_array(
            n, self.min_weight, self.max_weight)

        logger.debug('Test parameters (n, weights): (%d, %s)' % (n, w))
        with self.assertRaises(Exception) as context:
            lib_msg.generate_random_message_ver(w)

        self.assertIn(
            self.err_msg_prefix_invalid_n, context.exception.message,
            'Not found key: %s in error message: %s' % (
                self.err_msg_prefix_invalid_n, context.exception.message)
        )

    '''
    Generate an array with value is index in range(0, n)
    Output:
        Array
    '''

    def _gen_arr_msg_version_idx(self, n):
        arr = []

        for i in range(n):
            arr.append(i)

        return arr

    '''
    Test step by step to verify if the function generate_random_message_ver works correctly
    according to provided parameter: n, w, runtime and accept_wrong_percent_in_total
    Input:
        - n: number message version.
        - w: list of weights of each version
        - runtime: number of run to get message version 
        - accept_wrong_percent_in_total: Acceptable percent messages are wrongly distributed. By default: 10%
    Output:
        Ok if pass. Error message if wrong.
    '''

    def _test_step_by_step_valid_n_weight(self, n, w, runtime, accept_wrong_percent_in_total):
        # 1. Get actual and expected message distribution
        actual_msg_dist = lib_msg.get_actual_msg_distribution(w, runtime)
        expected_msg_dist = lib_msg.generate_expected_msg_distribution(
            w, runtime)

        list_ver_idx = self._gen_arr_msg_version_idx(n)

        logging.debug('Test info:\n n: %d \n runtime: %d\n [(idx, weight, exp_no_msg_version, act_no_msg_version)]: %s' %
                      (n, runtime, zip(list_ver_idx, w, expected_msg_dist, actual_msg_dist)))

        # 2. Get list message has wrong distribution
        list_msg_idx_wrong_dist = lib_msg.get_list_msg_idx_wrong_distribution(
            expected_msg_dist, actual_msg_dist)
        # 3. Calc % message distribution wrong in total
        no_msg_wrong_dist = lib_msg.count_msg_wrong_distribution(
            expected_msg_dist, actual_msg_dist)

        act_wrong_percent_in_total = float(
            no_msg_wrong_dist)/float(runtime)*100

        if len(list_msg_idx_wrong_dist) > 0:
            logging.debug(
                'List message wrong distribution (expected, actual): ')
            str = ''
            for idx in list_msg_idx_wrong_dist:
                str += '(%d, %d)' % (expected_msg_dist[idx],
                                     actual_msg_dist[idx])
                #logging.info('(%d, %d)' % (expected_msg_dist[idx], actual_msg_dist[idx]))

            logging.debug(str)

        logging.info(
            'No of msg wrong distribution per total: %d/%d. (%%Expected, %%Actual): (%0.00f(%%), %0.00f(%%))' %
            (no_msg_wrong_dist, runtime,
             accept_wrong_percent_in_total, act_wrong_percent_in_total)
        )
        self.assertLessEqual(
            act_wrong_percent_in_total, accept_wrong_percent_in_total,
            msg='Fail: (exp_wrong_pecent, act_wrong_percent): (%0.00f, %0.00f)' %
            (accept_wrong_percent_in_total, act_wrong_percent_in_total)
        )

    '''
    As developer, I want to test the case n = min_n. So that, check if the function generate_random_message_ver works correctly.

    Test info:
        - n: equal min_n
        - weights: random between min_weight and max_weight
        - runtime: Use default runtime set in config/config.json (2000)
    Expect:
        The function generate_random_message_ver works correctly with n = min_n
    '''
    def test_n_equal_min_n(self):
        n = self.min_n
        # Generate a random weight wiht n element
        w = lib_co.generate_random_int_array(
            n, self.min_weight, self.max_weight)

        self._test_step_by_step_valid_n_weight(
            n, w, self.runtime, self.accept_wrong_percent_in_total
        )

    '''
    As developer, I want to test the case n = max_n. So that, check if the function generate_random_message_id works correctly.

    Test info:
        - n: equal max_n
        - weights: random between min_weight and max_weight
        - runtime: Use default runtime from config/config.json
    Expect:
        The function generate_random_message_ver works correctly with n = max_n
    '''
    def test_n_equal_max_n(self):
        n = self.max_n
        # Generate a random weight wiht n element
        w = lib_co.generate_random_int_array(
            n, self.min_weight, self.max_weight)

        self._test_step_by_step_valid_n_weight(
            n, w, self.runtime, self.accept_wrong_percent_in_total
        )

    '''
    As developer, I want to test the case weight  < min_weight. 
    So that, check if the function generate_random_message_id handles invalid weight correctly.

    Test info:
        - n: random(min_n, max_n)
        - weights: invalid weight less than min_weight
        - runtime: Use default runtime from config/config.json
    Expect:
        The function generate_random_message_ver works correctly with weight = max_weight 
    '''

    def test_invalid_weight_less_than_min_weight(self):
        n = random.randint(self.min_n, self.max_n)
        w = lib_co.generate_random_int_array(
            n, self.min_weight - 10, self.min_weight - 1)

        logger.debug('Test parameters (n, weights): (%d, %s)' % (n, w))
        with self.assertRaises(Exception) as context:
            lib_msg.generate_random_message_ver(w)

        self.assertIn(
            self.err_msg_prefix_invalid_weight, context.exception.message,
            'Not found key: "%s" in error message: %s' % (
                self.err_msg_prefix_invalid_weight, context.exception.message)
        )

    '''
    As developer, 
    I want to test the case weight  > max_weight. 
    So that, check if the function generate_random_message_id handles invalid weight correctly.

    Test info:
        - n: random(min_n, max_n)
        - weights: invalid weight greater than max_weight
        - runtime: Use default runtime from config/config.json
    Expect:
        The function generate_random_message_ver works correctly with weight = max_weight 
    '''

    def test_invalid_weight_greater_than_max_weight(self):
        n = random.randint(self.min_n, self.max_n)
        w = lib_co.generate_random_int_array(
            n, self.max_weight + 1, self.max_weight + 10)

        logger.debug('Test parameters (n, weights): (%d, %s)' % (n, w))
        with self.assertRaises(Exception) as context:
            lib_msg.generate_random_message_ver(w)

        self.assertIn(
            self.err_msg_prefix_invalid_weight, context.exception.message,
            'Not found key: "%s" in error message: %s' % (
                self.err_msg_prefix_invalid_weight, context.exception.message)
        )

    '''
    As developer, I want to test the case weight = min_weight. So that, check if this function works correctly
    Test info:
        - n: random(min_n, max_n)
        - weights: min_weight
        - runtime: Use default runtime from config/config.json
    Expect:
        Function works correctly with weight = min_weight  
    '''

    def test_weight_equal_min_weight(self):
        n = random.randint(self.min_n, self.max_n)

        # Generate a random weight wiht n element
        w = lib_co.generate_random_int_array(
            n, self.min_weight, self.min_weight)

        self._test_step_by_step_valid_n_weight(
            n, w, self.runtime, self.accept_wrong_percent_in_total
        )

    '''
    As developer, I want to test the case weight = max_weight. So that, check if function works correctly
    Test info:
        - n: random(min_n, max_n)
        - weights: max_weight
        - runtime: Use default runtime from config/config.json
    Expect:
        The function generate_random_message_ver works correctly with weight = max_weight  
    '''

    def test_weight_equal_max_weight(self):
        n = random.randint(self.min_n, self.max_n)

        # Generate a random weight wiht n element
        w = lib_co.generate_random_int_array(
            n, self.max_weight, self.max_weight)

        self._test_step_by_step_valid_n_weight(
            n, w, self.runtime, self.accept_wrong_percent_in_total
        )

    '''
    As developer, I want to test the case random n and random weight. So that, check if function works correctly
    Test info:
        - n: random(min_n, max_n)
        - weights: random (min_weight, max_weight)
        - runtime: Use default runtime from config/config.json
    Expect:
        The function generate_random_message_ver works correctly with weight = max_weight 
    '''

    def test_random_n_and_weight_between_min_max(self):
        n = random.randint(self.min_n, self.max_n)

        # Generate a random weight wiht n element
        w = lib_co.generate_random_int_array(
            n, self.min_weight, self.max_weight)

        self._test_step_by_step_valid_n_weight(
            n, w, self.runtime, self.accept_wrong_percent_in_total
        )

    def tearDown(self):
        pass

if __name__ == '__main__':
    #import sys, os
    #print ('package: %s' % dir(__package__))
    #print dir(__file__)
    # os.getcwd()
    #print sys.path
    unittest.main(verbosity=2)
