import sys, os

#sys.path.append(os.getcwd())
sys.path.insert(1, '.')