import os

SETTINGS_JSON_FILE = os.path.abspath()